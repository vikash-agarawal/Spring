package com.cg.ui;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.bean.Employee;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Resource res=new ClassPathResource("beans.xml");
		XmlBeanFactory factory=new XmlBeanFactory(res);
		Employee employee1= (Employee) factory.getBean("e1");
		Employee employee2= (Employee) factory.getBean("e2");
		/*employee.setFirstName("A");
		employee.setLastName("Z");
		employee.setAge(21);*/
		System.out.println(employee1);
		System.out.println(employee2);
		
	}

}
